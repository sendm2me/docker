(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<html>\n\n<body>\n  <div class=\"container-fluid\">\n    <div class=\"row\">\n\n      <h1>\n        {{title}}\n      </h1>\n      <nav class=\"navbar navbar-inverse\">\n        <div class=\"container-fluid\">\n          <ul class=\"nav navbar-nav\">\n\t\t   <li>\n              <a routerLink=\"/addProject\">Add Project</a>\n            </li>\n            <li>\n              <a routerLink=\"/add\">Add Task</a>\n            </li>\n\t\t\t <li>\n              <a routerLink=\"/addUser\">Add User</a>\n            </li>\n            <li>\n              <a routerLink=\"/\">View Task</a>\n            </li>\n\n          </ul>\n        </div>\n      </nav>\n\n      <router-outlet></router-outlet>\n    </div>\n  </div>\n</body>\n\n</html>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'Project Manager';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _view_task_view_task_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./view-task/view-task.component */ "./src/app/view-task/view-task.component.ts");
/* harmony import */ var _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./task-form/task-form.component */ "./src/app/task-form/task-form.component.ts");
/* harmony import */ var _task_filter_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./task-filter.pipe */ "./src/app/task-filter.pipe.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var src_app_services_task_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/services/task.service */ "./src/app/services/task.service.ts");
/* harmony import */ var src_app_services_user_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
/* harmony import */ var _view_user_view_user_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./view-user/view-user.component */ "./src/app/view-user/view-user.component.ts");
/* harmony import */ var src_app_view_project_view_project_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/view-project/view-project.component */ "./src/app/view-project/view-project.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};















var appRoutes = [
    { path: '', component: _view_task_view_task_component__WEBPACK_IMPORTED_MODULE_6__["ViewTaskComponent"] },
    { path: 'edit/:id', component: _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_7__["TaskFormComponent"] },
    { path: 'add', component: _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_7__["TaskFormComponent"] },
    { path: 'addUser', component: _view_user_view_user_component__WEBPACK_IMPORTED_MODULE_13__["ViewUserComponent"] },
    { path: 'editUser/:id', component: _view_user_view_user_component__WEBPACK_IMPORTED_MODULE_13__["ViewUserComponent"] },
    { path: 'addProject', component: src_app_view_project_view_project_component__WEBPACK_IMPORTED_MODULE_14__["ViewProjectComponent"] },
    { path: 'editProject/:id', component: src_app_view_project_view_project_component__WEBPACK_IMPORTED_MODULE_14__["ViewProjectComponent"] }
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _view_task_view_task_component__WEBPACK_IMPORTED_MODULE_6__["ViewTaskComponent"],
                _task_form_task_form_component__WEBPACK_IMPORTED_MODULE_7__["TaskFormComponent"],
                _task_filter_pipe__WEBPACK_IMPORTED_MODULE_8__["TaskFilterPipe"],
                _view_user_view_user_component__WEBPACK_IMPORTED_MODULE_13__["ViewUserComponent"],
                src_app_view_project_view_project_component__WEBPACK_IMPORTED_MODULE_14__["ViewProjectComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_4__["HttpModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(appRoutes)
            ],
            providers: [
                src_app_services_task_service__WEBPACK_IMPORTED_MODULE_10__["TaskService"],
                src_app_services_user_service__WEBPACK_IMPORTED_MODULE_11__["UserService"],
                src_app_services_project_service__WEBPACK_IMPORTED_MODULE_12__["ProjectService"],
                _angular_common__WEBPACK_IMPORTED_MODULE_9__["DatePipe"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/models/project.ts":
/*!***********************************!*\
  !*** ./src/app/models/project.ts ***!
  \***********************************/
/*! exports provided: Project */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Project", function() { return Project; });
var Project = /** @class */ (function () {
    function Project() {
    }
    return Project;
}());



/***/ }),

/***/ "./src/app/models/task.ts":
/*!********************************!*\
  !*** ./src/app/models/task.ts ***!
  \********************************/
/*! exports provided: Task */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Task", function() { return Task; });
var Task = /** @class */ (function () {
    function Task() {
    }
    return Task;
}());



/***/ }),

/***/ "./src/app/models/user.ts":
/*!********************************!*\
  !*** ./src/app/models/user.ts ***!
  \********************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
var User = /** @class */ (function () {
    function User() {
    }
    return User;
}());



/***/ }),

/***/ "./src/app/services/project.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/project.service.ts ***!
  \*********************************************/
/*! exports provided: ProjectService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProjectService", function() { return ProjectService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ProjectService = /** @class */ (function () {
    function ProjectService(http) {
        this.http = http;
        this.empUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseProjectUrl;
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({ 'content-Type': 'application/json' });
        this.httpOptions = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["RequestOptions"]({ headers: headers });
    }
    ProjectService.prototype.getProjects = function () {
        return this.http.get(this.empUrl).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    ProjectService.prototype.getProjectsById = function (projectId) {
        return this.http.get(this.getUrlById(projectId)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    ProjectService.prototype.getUrlById = function (empId) {
        return this.empUrl + "/" + empId;
    };
    ProjectService.prototype.addProject = function (emp) {
        return this.http.post(this.empUrl, JSON.stringify(emp), this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    ProjectService.prototype.updateProject = function (emp) {
        return this.http.put(this.empUrl, JSON.stringify(emp), this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    ProjectService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], ProjectService);
    return ProjectService;
}());



/***/ }),

/***/ "./src/app/services/task.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/task.service.ts ***!
  \******************************************/
/*! exports provided: TaskService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskService", function() { return TaskService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var TaskService = /** @class */ (function () {
    function TaskService(http) {
        this.http = http;
        this.empUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseEmpUrl;
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({ 'content-Type': 'application/json' });
        this.httpOptions = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["RequestOptions"]({ headers: headers });
    }
    TaskService.prototype.getTasks = function () {
        return this.http.get(this.empUrl).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    TaskService.prototype.getTasksById = function (taskId) {
        return this.http.get(this.getUrlById(taskId)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    TaskService.prototype.getUrlById = function (empId) {
        return this.empUrl + "/" + empId;
    };
    TaskService.prototype.addTask = function (emp) {
        return this.http.post(this.empUrl, JSON.stringify(emp), this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    TaskService.prototype.updateTask = function (emp) {
        return this.http.put(this.empUrl, JSON.stringify(emp), this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    TaskService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], TaskService);
    return TaskService;
}());



/***/ }),

/***/ "./src/app/services/user.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/user.service.ts ***!
  \******************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var UserService = /** @class */ (function () {
    function UserService(http) {
        this.http = http;
        this.empUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].baseUserUrl;
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({ 'content-Type': 'application/json' });
        this.httpOptions = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["RequestOptions"]({ headers: headers });
    }
    UserService.prototype.getUsers = function () {
        return this.http.get(this.empUrl).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    UserService.prototype.getUsersById = function (userId) {
        return this.http.get(this.getUrlById(userId)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    UserService.prototype.getUrlById = function (empId) {
        return this.empUrl + "/" + empId;
    };
    UserService.prototype.addUser = function (emp) {
        return this.http.post(this.empUrl, JSON.stringify(emp), this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    UserService.prototype.updateUser = function (emp) {
        return this.http.put(this.empUrl, JSON.stringify(emp), this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    UserService.prototype.deleteUsersById = function (userId) {
        return this.http.delete(this.getUrlById(userId)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (resp) { return resp.json(); }));
    };
    UserService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/app/task-filter.pipe.ts":
/*!*************************************!*\
  !*** ./src/app/task-filter.pipe.ts ***!
  \*************************************/
/*! exports provided: TaskFilterPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskFilterPipe", function() { return TaskFilterPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var TaskFilterPipe = /** @class */ (function () {
    function TaskFilterPipe() {
    }
    TaskFilterPipe.prototype.transform = function (value, args) {
        var originalValue = value;
        if ((args.task === undefined || args.task == "")
            && (args.parentId === undefined)
            && (args.priority === undefined)
            && (args.startDate === undefined)
            && (args.endDate === undefined)) {
            return originalValue;
        }
        if (args) {
            //console.log(args);
        }
        return value.filter(function (t) {
            if ((t.task == args.task)
                && ((t.parentId == args.parentId) || (t.parentId != null && args.parentId != null && t.parentId.taskId == args.parentId.taskId))
                && (t.priority == args.priority)
                && (t.startDate == args.startDate)
                && (t.endDate == args.endDate)) {
                return true;
            }
        });
    };
    TaskFilterPipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'taskFilter',
            pure: false
        })
    ], TaskFilterPipe);
    return TaskFilterPipe;
}());



/***/ }),

/***/ "./src/app/task-form/task-form.component.css":
/*!***************************************************!*\
  !*** ./src/app/task-form/task-form.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/task-form/task-form.component.html":
/*!****************************************************!*\
  !*** ./src/app/task-form/task-form.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid\">\n\n  <div class=\"row\">\n    <section>\n      <form class=\"form-horizontal\" #heroForm=\"ngForm\">\n        <div class=\"form-group col-sm-12\">*Required Fields</div>\n        <div class=\"form-group col-sm-7\">\n            <label>Project:</label>\n            <input disabled class=\"form-control\" type=\"text\" name=\"project\" [(ngModel)]=\"project\" />        \n        </div>\n        <div class=\"btn-group col-sm-3\">\n            <button type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#projectOnlyModal\" (click)=\"addOnlyProjectModalSearchButtonLogic() \">Search</button>\n        </div>\n\n        <div class=\"form-group col-sm-7\">\n          <label>*Task:</label>\n          <input  placeholder=\"Enter Task\" class=\"form-control\" type=\"text\" name=\"task\" [(ngModel)]=\"task.task\" required/>\n        </div>\n\n        <div class=\"form-group col-sm-12\">\n            <input type=\"checkbox\" name=\"setDate\" [checked]=\"checkedorNot\" value=\"Bike\" (change)=\"dates($event)\">Parent Task\n          </div>\n\n        <div class=\"form-group col-sm-7\">\n          <label>Priority:</label>\n          <input [disabled]=\"checkedorNot\" placeholder=\"Enter Priority\" class=\"form-control\" type=\"decimal\" name=\"sal\" [(ngModel)]=\"task.priority\" required min=\"10000\"\n            max=\"25000\" />\n        </div>\n\n        <div class=\"form-group col-sm-7\">\n          <label>ParentTaskId:</label>\n          <input disabled  class=\"form-control\" type=\"text\" name=\"parentId\" [(ngModel)]=\"parentId\" />          \n        </div>\n        <div class=\"btn-group col-sm-3\">\n            <button [disabled]=\"checkedorNot\" type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#parentModal\" (click)=\"addParentModalSearchButtonLogic() \">Search</button>          \n        </div>\n\n        <div class=\"form-group col-sm-7\">\n          <label>StartDate:</label>\n          <input [disabled]=\"checkedorNot\" class=\"form-control\" type=\"date\" name=\"doj\" [(ngModel)]=\"startDate\" (change)=\"updateStartDate()\" required />\n        </div>\n\n        <div class=\"form-group col-sm-7\">\n            <label>User:</label>\n            <input disabled class=\"form-control\" type=\"text\" name=\"userId\" [(ngModel)]=\"userEmployeeId\" />\n            \n        </div>\n        <div class=\"btn-group col-sm-3\">\n            <button type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#projectModal\" (click)=\"addManagerModalSearchButtonLogic() \">Search</button>\n        </div>\n\n        <div class=\"btn-group col-sm-12\">\n          <button *ngIf=\"isNew\" class=\"btn\" type=\"submit\" (click)=\"saveTask()\" [disabled]=\"!heroForm.form.valid\">Add Task</button>\n          <button *ngIf=\"isNew\" class=\"btn\" type=\"reset\">Reset</button>\n\n          <button *ngIf=\"!isNew\" class=\"btn\" type=\"submit\" (click)=\"saveTask()\" [disabled]=\"!heroForm.form.valid\">Update</button>\n          <button *ngIf=\"!isNew\" class=\"btn\" type=\"submit\" (click)=\"cancelButton()\">Cancel</button>\n        </div>\n\n      </form>\n\n\n\n      <div id=\"parentModal\" class=\"modal fade\" role=\"dialog\">\n        <div class=\"modal-dialog\">\n\n          <!-- Modal content-->\n          <div class=\"modal-content\">\n            <div class=\"modal-header\">\n              <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n              <h4 class=\"modal-title\">Add Parent Task</h4>\n            </div>\n            <div class=\"modal-body\">\n\n              <form class=\"form-inline\" #heroForm1=\"ngForm\">\n                <div class=\"form-group col-sm-9\">*Required Fields</div>\n                <div class=\"form-group col-sm-12\">\n                  <label>*Task:</label>\n                  <div>\n                    <input class=\"form-control\" type=\"text\" placeholder=\"Enter Task\" name=\"filterTaskId\" [(ngModel)]=\"filterTaskId\" required/>\n                  </div>\n                </div>\n                <div class=\"btn-group col-sm-2\">\n                  <button type=\"submit\" class=\"btn\" (click)=\"insideParentModalSearchButtonLogic()\" [disabled]=\"!heroForm1.form.valid\">Search</button>\n                </div>\n                <div class=\"btn-group col-sm-1\">\n                  <button type=\"reset\" class=\"btn\" (click)=\"resetInsideParentModalSearchButtonLogic()\">Reset</button>\n                </div>\n              </form>\n\n              <table class=\"table\">\n                <thead>\n                  <tr>\n                    <th>TaskId</th>\n                    <th>Task</th>\n                  </tr>\n                </thead>\n                <tbody>\n                  <tr *ngFor=\"let task of filteredParentModalTasks\">\n                    <ng-container *ngIf='task.parentId==null'>\n                      <td>{{task.taskId}}</td>\n                      <td>{{task.task}}</td>\n\n                      <td>\n                        <button type=\"button\" class=\"btn\" id=\"btnAdd1\" data-dismiss=\"modal\" (click)=\"parentModalSelectButtonLogic(task.taskId)\">Select Task</button>\n                      </td>\n                    </ng-container>\n                  </tr>\n                </tbody>\n              </table>\n\n            </div>\n            <div class=\"modal-footer\">\n              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\n            </div>\n          </div>\n        </div>\n      </div>\n\n\n      <div id=\"projectModal\" class=\"modal fade\" role=\"dialog\">\n          <div class=\"modal-dialog\">\n  \n            <!-- Modal content-->\n            <div class=\"modal-content\">\n              <div class=\"modal-header\">\n                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n                <h4 class=\"modal-title\">Add User</h4>\n              </div>\n              <div class=\"modal-body\">                 \n  \n                <form class=\"form-inline\" #projectModalForm=\"ngForm\">\n                  <div class=\"form-group col-sm-9\">*Required Fields</div>\n                  <div class=\"form-group col-sm-12\">\n                    <label>*EmployeeId:</label>\n                    <div>\n                      <input class=\"form-control\" type=\"text\" placeholder=\"Enter EmployeeId\" name=\"filterTaskId\" [(ngModel)]=\"filterTaskId\" required/>\n                    </div>\n                  </div>\n                  <div class=\"btn-group col-sm-2\">\n                    <button type=\"submit\" class=\"btn\" (click)=\"insideManagerModalSearchButtonLogic()\" [disabled]=\"!projectModalForm.form.valid\">Search</button>\n                  </div>\n                  <div class=\"btn-group col-sm-1\">\n                    <button type=\"reset\" class=\"btn\" (click)=\"resetInsideManagerModalSearchButtonLogic()\">Reset</button>\n                  </div>\n                </form>\n  \n  \n  \n                <table class=\"table\">\n                  <thead>\n                    <tr>\n                      <th>UserId</th>\n                      <th>FirstName</th>\n                      <th>LastName</th>\n                      <th>EmployeeId</th>\n                    </tr>\n                  </thead>\n                  <tbody>\n                    <tr *ngFor=\"let user of filteredManagerModalTasks\">\n                      <td>{{user.userId}}</td>\n                      <td>{{user.firstName}}</td>\n                      <td>{{user.lastName}}</td>\n                      <td>{{user.employeeId}}</td>\n                      <td>\n                        <button type=\"button\" class=\"btn\" id=\"btnAdd1\" data-dismiss=\"modal\" (click)=\"projectModalSelectButtonLogic(user.employeeId,user.userId)\">Select Task</button>\n                      </td>\n                    </tr>\n                  </tbody>\n                </table>\n  \n              </div>\n              <div class=\"modal-footer\">\n                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\n              </div>\n            </div>\n          </div>\n        </div>\n\n\n        <div id=\"projectOnlyModal\" class=\"modal fade\" role=\"dialog\">\n            <div class=\"modal-dialog\">\n    \n              <!-- Modal content-->\n              <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                  <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n                  <h4 class=\"modal-title\">Add Project</h4>\n                </div>\n                <div class=\"modal-body\">                     \n    \n                  <form class=\"form-horizontal\" #projectForm=\"ngForm\">\n                      <div class=\"form-group col-sm-12\">*Required Fields</div>\n                      <div class=\"form-group col-sm-7\">\n                        <label>*Project:</label>\n                        <input placeholder=\"Enter Project\" class=\"form-control\" type=\"text\" name=\"Project\" [(ngModel)]=\"filterproject\" required/>\n                      </div>\n\n                  <div class=\"btn-group col-sm-2\">\n                    <button type=\"submit\" class=\"btn\" (click)=\"insideOnlyProjectModalSearchButtonLogic()\" [disabled]=\"!projectForm.form.valid\">Search</button>\n                  </div>\n                  <div class=\"btn-group col-sm-1\">\n                    <button type=\"reset\" class=\"btn\" (click)=\"resetInsideOnlyProjectModalSearchButtonLogic()\">Reset</button>\n                  </div>              \n              \n                    </form>                 \n       \n    \n                    <table class=\"table\">\n                        <thead>\n                          <tr>\n                            <th>ProjectId</th>\n                            <th>Project</th>                                        \n                          </tr>\n                        </thead>\n                        <tbody>\n                          <tr *ngFor=\"let project of filteredOnlyProjectModalTasks\">\n                            <td>{{project.projectId}}</td>\n                            <td>{{project.project}}</td>\n                            <td>\n                                <button type=\"button\" class=\"btn\" id=\"btnAdd1\" data-dismiss=\"modal\" (click)=\"onlyProjectModalSelectButtonLogic(project.project,project.projectId)\">Select Task</button>\n                            </td>                \n                          </tr>\n                        </tbody>\n                      </table>\n    \n                </div>\n                <div class=\"modal-footer\">\n                  <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\n                </div>\n              </div>\n            </div>\n          </div>\n\n    </section>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/task-form/task-form.component.ts":
/*!**************************************************!*\
  !*** ./src/app/task-form/task-form.component.ts ***!
  \**************************************************/
/*! exports provided: TaskFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskFormComponent", function() { return TaskFormComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_models_task__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/task */ "./src/app/models/task.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var src_app_services_task_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/task.service */ "./src/app/services/task.service.ts");
/* harmony import */ var src_app_services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var TaskFormComponent = /** @class */ (function () {
    function TaskFormComponent(taskService, router, route, datePipe, userService, projectService) {
        this.taskService = taskService;
        this.router = router;
        this.route = route;
        this.datePipe = datePipe;
        this.userService = userService;
        this.projectService = projectService;
        this.checkedorNot = false;
        this.task = new src_app_models_task__WEBPACK_IMPORTED_MODULE_1__["Task"]();
    }
    TaskFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.subscribe(function (params) {
            if (params['id'] != null) {
                _this.taskService.getTasksById(params['id']).subscribe(function (data) {
                    _this.task = data;
                    _this.startDate = _this.datePipe.transform(_this.task.startDate, 'yyyy-MM-dd');
                    if (_this.task.parentId != null)
                        _this.parentId = _this.task.parentId.taskId;
                    else
                        _this.parentId = null;
                    if (_this.task.userId != null)
                        _this.userEmployeeId = _this.task.userId.employeeId;
                    else
                        _this.userEmployeeId = null;
                    if (_this.task.projectId != null)
                        _this.project = _this.task.projectId.project;
                    else
                        _this.project = null;
                });
                _this.isNew = false;
            }
            else {
                _this.task = new src_app_models_task__WEBPACK_IMPORTED_MODULE_1__["Task"]();
                _this.isNew = true;
                //this.startDate = (new Date()).toISOString().substr(0, 10);
                _this.startDate = _this.datePipe.transform(new Date(), 'yyyy-MM-dd');
            }
        });
    };
    TaskFormComponent.prototype.updateStartDate = function () {
        this.task.startDate = new Date(this.startDate);
    };
    TaskFormComponent.prototype.saveTask = function () {
        var _this = this;
        if (this.isNew) {
            if (this.parentId != null && this.parentId > 0) {
                if (this.finaluser != null) {
                    this.task.userId = this.finaluser;
                }
                if (this.finalProject != null) {
                    this.task.projectId = this.finalProject;
                }
                this.taskService.getTasksById(this.parentId).subscribe(function (empData) {
                    _this.task.parentId = empData;
                    if (_this.startDate != null)
                        _this.task.startDate = new Date(_this.startDate);
                    _this.taskService.addTask(_this.task).subscribe(function (data) {
                        alert(data.taskId + " is added successfully");
                        _this.router.navigate(["/"]);
                    });
                });
            }
            else {
                this.task.parentId = null;
                if (this.finaluser != null) {
                    this.task.userId = this.finaluser;
                }
                if (this.finalProject != null) {
                    this.task.projectId = this.finalProject;
                }
                if (this.startDate != null)
                    this.task.startDate = new Date(this.startDate);
                this.taskService.addTask(this.task).subscribe(function (data) {
                    alert(data.taskId + " is added successfully");
                    _this.router.navigate(["/"]);
                });
            }
        }
        else {
            this.updateButtonLogic();
        }
    };
    TaskFormComponent.prototype.cancelButton = function () {
        window.location.href = "/";
    };
    TaskFormComponent.prototype.updateButtonLogic = function () {
        var _this = this;
        if (this.parentId != null && this.parentId > 0) {
            if (this.finaluser != null) {
                this.task.userId = this.finaluser;
            }
            if (this.finalProject != null) {
                this.task.projectId = this.finalProject;
            }
            this.taskService.getTasksById(this.parentId).subscribe(function (empData) {
                _this.task.parentId = empData;
                _this.taskService.updateTask(_this.task).subscribe(function (data) {
                    alert(data.taskId + " is updated successfully");
                    _this.router.navigate(["/"]);
                });
            });
        }
        else {
            //parent from update form is empty
            this.task.parentId = null;
            if (this.finaluser != null) {
                this.task.userId = this.finaluser;
            }
            if (this.finalProject != null) {
                this.task.projectId = this.finalProject;
            }
            this.taskService.updateTask(this.task).subscribe(function (data) {
                alert(data.taskId + "is updated successfully");
                _this.router.navigate(["/"]);
            });
        }
    };
    TaskFormComponent.prototype.addParentModalSearchButtonLogic = function () {
        var _this = this;
        this.taskService.getTasks().subscribe(function (empData) {
            _this.filteredParentModalTasks = empData;
            _this.storeOrignalFilterParentModalTasks = empData;
        });
        this.filterTaskId = null;
    };
    TaskFormComponent.prototype.parentModalSelectButtonLogic = function (taskId) {
        this.parentId = taskId;
    };
    TaskFormComponent.prototype.insideParentModalSearchButtonLogic = function () {
        var _this = this;
        var finalResult = this.filteredParentModalTasks.filter(function (t) {
            if (t.task == _this.filterTaskId) {
                return true;
            }
        });
        this.filteredParentModalTasks = finalResult;
    };
    TaskFormComponent.prototype.resetInsideParentModalSearchButtonLogic = function () {
        this.filterTaskId = null;
        this.filteredParentModalTasks = this.storeOrignalFilterParentModalTasks;
    };
    TaskFormComponent.prototype.addManagerModalSearchButtonLogic = function () {
        var _this = this;
        this.userService.getUsers().subscribe(function (empData) {
            _this.filteredManagerModalTasks = empData;
            _this.storeOrignalFilterManagerModalTasks = empData;
        });
        this.filterTaskId = null;
    };
    TaskFormComponent.prototype.projectModalSelectButtonLogic = function (employeeId, userId) {
        var _this = this;
        this.userEmployeeId = employeeId;
        this.userId = userId;
        this.userService.getUsersById(this.userId).subscribe(function (data) {
            _this.finaluser = data;
        });
    };
    TaskFormComponent.prototype.insideManagerModalSearchButtonLogic = function () {
        //alert(this.filterTaskId);
        var _this = this;
        var finalResult = this.filteredManagerModalTasks.filter(function (t) {
            if (t.employeeId == _this.filterTaskId) {
                return true;
            }
        });
        this.filteredManagerModalTasks = finalResult;
        //console.log(finalResult);
    };
    TaskFormComponent.prototype.resetInsideManagerModalSearchButtonLogic = function () {
        this.filterTaskId = null;
        this.filteredManagerModalTasks = this.storeOrignalFilterManagerModalTasks;
    };
    TaskFormComponent.prototype.addOnlyProjectModalSearchButtonLogic = function () {
        var _this = this;
        this.projectService.getProjects().subscribe(function (empData) {
            _this.filteredOnlyProjectModalTasks = empData;
            _this.storeOrignalFilterOnlyProjectModalTasks = empData;
        });
        this.filterproject = null;
    };
    TaskFormComponent.prototype.onlyProjectModalSelectButtonLogic = function (employeeId, userId) {
        var _this = this;
        this.project = employeeId;
        this.projectId = userId;
        this.projectService.getProjectsById(this.projectId).subscribe(function (data) {
            _this.finalProject = data;
        });
    };
    TaskFormComponent.prototype.insideOnlyProjectModalSearchButtonLogic = function () {
        //alert(this.filterproject);
        var _this = this;
        var finalResult = this.filteredOnlyProjectModalTasks.filter(function (t) {
            if (t.project == _this.filterproject) {
                return true;
            }
        });
        this.filteredOnlyProjectModalTasks = finalResult;
        //console.log(finalResult);
    };
    TaskFormComponent.prototype.resetInsideOnlyProjectModalSearchButtonLogic = function () {
        this.filterproject = null;
        this.filteredOnlyProjectModalTasks = this.storeOrignalFilterOnlyProjectModalTasks;
    };
    TaskFormComponent.prototype.dates = function (event) {
        if (event.target.checked) {
            this.checkedorNot = true;
            this.startDate = null;
        }
        else {
            this.checkedorNot = false;
            this.startDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
        }
    };
    TaskFormComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-task-form',
            template: __webpack_require__(/*! ./task-form.component.html */ "./src/app/task-form/task-form.component.html"),
            styles: [__webpack_require__(/*! ./task-form.component.css */ "./src/app/task-form/task-form.component.css")]
        }),
        __metadata("design:paramtypes", [src_app_services_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"], src_app_services_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"],
            src_app_services_project_service__WEBPACK_IMPORTED_MODULE_6__["ProjectService"]])
    ], TaskFormComponent);
    return TaskFormComponent;
}());



/***/ }),

/***/ "./src/app/view-project/view-project.component.css":
/*!*********************************************************!*\
  !*** ./src/app/view-project/view-project.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/view-project/view-project.component.html":
/*!**********************************************************!*\
  !*** ./src/app/view-project/view-project.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid\">\n\n  <div class=\"row\">\n    <section>\n\n      <form class=\"form-horizontal\" #projectForm=\"ngForm\">\n        <div class=\"form-group col-sm-12\">*Required Fields</div>\n        <div class=\"form-group col-sm-7\">\n          <label>*Project:</label>\n          <input placeholder=\"Enter Project\" class=\"form-control\" type=\"text\" name=\"Project\" [(ngModel)]=\"project.project\" required/>\n        </div>\n        <div class=\"form-group col-sm-12\">\n          <input type=\"checkbox\" name=\"setDate\" [checked]=\"checkedorNot\" value=\"Bike\" (change)=\"dates($event)\"> Set Start and End Date\n        </div>\n        <div class=\"form-group col-sm-7\">\n          <label>StartDate:</label>\n          <input class=\"form-control\" [disabled]=\"!checkedorNot\" type=\"date\" name=\"doj\" [(ngModel)]=\"startDate\" />\n\n\n          <label>EndDate:</label>\n          <input class=\"form-control\" [disabled]=\"!checkedorNot\" type=\"date\" name=\"doj1\" [(ngModel)]=\"endDate\" (blur)=endDateValidation()/>\n\n        </div>\n        <div class=\"form-group col-sm-7\">\n          <label>*Priority:</label>\n          <input placeholder=\"Enter Priority\" class=\"form-control\" type=\"decimal\" name=\"Priority\" [(ngModel)]=\"project.priority\" required\n          />\n        </div>\n\n        <div class=\"form-group col-sm-7\">\n          <label>Manager:</label>\n          <input placeholder=\"Enter Manager\" disabled class=\"form-control\" type=\"text\" name=\"Manager\" [(ngModel)]=\"userEmployeeId\"\n          />\n        </div>\n        <div class=\"btn-group col-sm-3\">\n          <button type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#projectModal\" (click)=\"addManagerModalSearchButtonLogic() \">Search</button>\n        </div>\n\n\n        <div class=\"btn-group col-sm-12\">\n          <button *ngIf=\"isNew\" class=\"btn\" type=\"submit\" (click)=\"saveProject()\" [disabled]=\"!projectForm.form.valid\">Add</button>\n          <button *ngIf=\"!isNew\" class=\"btn\" type=\"submit\" (click)=\"saveProject()\" [disabled]=\"!projectForm.form.valid\">Update</button>\n          <button class=\"btn\" type=\"reset\">Reset</button>\n        </div>\n\n      </form>\n\n      <div class=\"form-group col-sm-12\">\n        <br/>      \n      <div style=\"border-top: 1px solid\"></div>      \n      </div>      \n\n      <form class=\"form-inline\" #filterProjectForm=\"ngForm\">\n          <div class=\"form-group col-sm-7\">\n              <label>Project:</label>\n              <input disabled class=\"form-control\" type=\"text\" name=\"project\" [(ngModel)]=\"projectString\" />\n              <button type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#projectOnlyModal\" (click)=\"addOnlyProjectModalSearchButtonLogic() \">Search</button>\n              <button class=\"btn\" type=\"reset\" (click)=\"resetfilterBasedOnProjects()\">Reset</button>          \n          </div>\n          \n      </form>\n      \n      <div class=\"form-group col-sm-12\"></div>\n      <div class=\"form-group col-sm-3 \">\n        <label> Sort By:</label>\n      </div>\n      <div class=\"btn-group col-sm-8\">\n        <button type=\"button\" class=\"btn\" id=\"btnfname1\" (click)=sortProjectStartDate()>Start Date</button>\n        <button type=\"button\" class=\"btn\" id=\"btnlname\" (click)=sortProjectEndDate()>End Date</button>\n        <button type=\"button\" class=\"btn\" id=\"btneid\" (click)=sortProjectPriority()>Priority</button>\n        <button type=\"button\" class=\"btn\" id=\"btneid\" (click)=sortProjectCompletedTask()>Completed Tasks</button>\n      </div>\n\n      <div class=\"form-group col-sm-12 \">\n          Note: Once we click on Suspend button, all the Task mapped to Project will be Ended.\n      </div>\n\n      <table class=\"table\">\n        <thead>\n          <tr>\n            <th>ProjectId</th>\n            <th>Project</th>\n            <th>No of Tasks</th>\n            <th>Completed Tasks</th>\n            <th>Start Date</th>\n            <th>End Date</th>\n            <th>Priority</th>\n\n          </tr>\n        </thead>\n        <tbody>\n          <tr *ngFor=\"let project of filteredProjectsList\">\n            <td>{{project.projectId}}</td>\n            <td>{{project.project}}</td>\n            <td>{{project.noOfTask}}</td>\n            <td>{{project.noOfCompletedTask}}</td>\n            <td>{{project.startDate}}</td>\n            <td>{{project.endDate}}</td>\n            <td>{{project.priority}}</td>\n\n            <td>\n              <button type=\"button\" class=\"btn\" id=\"btnAdd1\" [routerLink]=\"['/editProject',project.projectId]\">Update</button>\n\n            </td>\n            <td>\n              <button type=\"button\" class=\"btn\" id=\"btnAdd2\"  (click)=\"endProject(project.projectId)\">Suspend</button>\n            </td>\n\n          </tr>\n        </tbody>\n      </table>\n\n      <div id=\"projectModal\" class=\"modal fade\" role=\"dialog\">\n        <div class=\"modal-dialog\">\n\n          <!-- Modal content-->\n          <div class=\"modal-content\">\n            <div class=\"modal-header\">\n              <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n              <h4 class=\"modal-title\">Add Manager</h4>\n            </div>\n            <div class=\"modal-body\">             \n\n              <form class=\"form-inline\" #projectModalForm=\"ngForm\">\n                <div class=\"form-group col-sm-9\">*Required Fields</div>\n                <div class=\"form-group col-sm-12\">\n                  <label>*EmployeeId:</label>\n                  <div>\n                    <input class=\"form-control\" type=\"text\" placeholder=\"Enter EmployeeId\" name=\"filterTaskId\" [(ngModel)]=\"filterTaskId\" required/>\n                  </div>\n                </div>\n                <div class=\"btn-group col-sm-2\">\n                  <button type=\"submit\" class=\"btn\" (click)=\"insideManagerModalSearchButtonLogic()\" [disabled]=\"!projectModalForm.form.valid\">Search</button>\n                </div>\n                <div class=\"btn-group col-sm-1\">\n                  <button type=\"reset\" class=\"btn\" (click)=\"resetInsideManagerModalSearchButtonLogic()\">Reset</button>\n                </div>\n              </form>\n\n\n\n              <table class=\"table\">\n                <thead>\n                  <tr>\n                    <th>UserId</th>\n                    <th>FirstName</th>\n                    <th>LastName</th>\n                    <th>EmployeeId</th>\n                  </tr>\n                </thead>\n                <tbody>\n                  <tr *ngFor=\"let user of filteredManagerModalTasks\">\n                    <td>{{user.userId}}</td>\n                    <td>{{user.firstName}}</td>\n                    <td>{{user.lastName}}</td>\n                    <td>{{user.employeeId}}</td>\n                    <td>\n                      <button type=\"button\" class=\"btn\" id=\"btnAdd1\" data-dismiss=\"modal\" (click)=\"projectModalSelectButtonLogic(user.employeeId,user.userId)\">Select Task</button>\n                    </td>\n                  </tr>\n                </tbody>\n              </table>\n\n            </div>\n            <div class=\"modal-footer\">\n              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\n            </div>\n          </div>\n        </div>\n      </div>\n\n\n      <div id=\"projectOnlyModal\" class=\"modal fade\" role=\"dialog\">\n          <div class=\"modal-dialog\">\n  \n            <!-- Modal content-->\n            <div class=\"modal-content\">\n              <div class=\"modal-header\">\n                <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n                <h4 class=\"modal-title\">Add Project</h4>\n              </div>\n              <div class=\"modal-body\">\n  \n                <form class=\"form-horizontal\" #projectForm1=\"ngForm\">\n                    <div class=\"form-group col-sm-12\">*Required Fields</div>\n                    <div class=\"form-group col-sm-7\">\n                      <label>*Project:</label>\n                      <input placeholder=\"Enter Project\" class=\"form-control\" type=\"text\" name=\"Project\" [(ngModel)]=\"filterproject\" required/>\n                    </div>\n\n                <div class=\"btn-group col-sm-2\">\n                  <button type=\"submit\" class=\"btn\" (click)=\"insideOnlyProjectModalSearchButtonLogic()\" [disabled]=\"!projectForm1.form.valid\">Search</button>\n                </div>\n                <div class=\"btn-group col-sm-1\">\n                  <button type=\"reset\" class=\"btn\" (click)=\"resetInsideOnlyProjectModalSearchButtonLogic()\">Reset</button>\n                </div>              \n            \n                  </form>                 \n     \n  \n                  <table class=\"table\">\n                      <thead>\n                        <tr>\n                          <th>ProjectId</th>\n                          <th>Project</th>                                        \n                        </tr>\n                      </thead>\n                      <tbody>\n                        <tr *ngFor=\"let project of filteredOnlyProjectModalTasks\">\n                          <td>{{project.projectId}}</td>\n                          <td>{{project.project}}</td>\n                          <td>\n                              <button type=\"button\" class=\"btn\" id=\"btnAdd1\" data-dismiss=\"modal\" (click)=\"onlyProjectModalSelectButtonLogic(project.project,project.projectId)\">Select Task</button>\n                          </td>                \n                        </tr>\n                      </tbody>\n                    </table>\n  \n              </div>\n              <div class=\"modal-footer\">\n                <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\n              </div>\n            </div>\n          </div>\n        </div>\n\n    </section>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/view-project/view-project.component.ts":
/*!********************************************************!*\
  !*** ./src/app/view-project/view-project.component.ts ***!
  \********************************************************/
/*! exports provided: ViewProjectComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewProjectComponent", function() { return ViewProjectComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_models_project__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/project */ "./src/app/models/project.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
/* harmony import */ var src_app_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var src_app_services_task_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/task.service */ "./src/app/services/task.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var ViewProjectComponent = /** @class */ (function () {
    function ViewProjectComponent(projectService, router, route, datePipe, userService, taskService) {
        this.projectService = projectService;
        this.router = router;
        this.route = route;
        this.datePipe = datePipe;
        this.userService = userService;
        this.taskService = taskService;
        this.startDateReverseSort = false;
        this.priorityReverseSort = false;
        this.endDateReverseSort = false;
        this.completedTaskReverseSort = false;
        this.project = new src_app_models_project__WEBPACK_IMPORTED_MODULE_1__["Project"]();
    }
    ViewProjectComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.projectService.getProjects().subscribe(function (empData) {
            _this.projects = empData;
            _this.storeOrignalFilterProjectsList = empData;
            _this.filteredProjectsList = empData;
            _this.taskService.getTasks().subscribe(function (empData) {
                _this.tasks = empData;
                _this.projects.filter(function (singleProject) {
                    var taskCount = 0;
                    var completedTaskCount = 0;
                    _this.tasks.filter(function (t) {
                        if (t.projectId != null && t.projectId.projectId == singleProject.projectId) {
                            taskCount++;
                            if (t.endDate != null) {
                                completedTaskCount++;
                            }
                        }
                    });
                    singleProject.noOfTask = taskCount;
                    singleProject.noOfCompletedTask = completedTaskCount;
                });
            });
        });
        this.route.params.subscribe(function (params) {
            if (params['id'] != null) {
                _this.projectService.getProjectsById(params['id']).subscribe(function (data) {
                    _this.project = data;
                    _this.startDate = _this.datePipe.transform(_this.project.startDate, 'yyyy-MM-dd');
                    _this.endDate = _this.datePipe.transform(_this.project.endDate, 'yyyy-MM-dd');
                    if (_this.project.userId != null) {
                        _this.userId = _this.project.userId.userId;
                        _this.userEmployeeId = _this.project.userId.employeeId;
                    }
                });
                _this.isNew = false;
            }
            else {
                _this.project = new src_app_models_project__WEBPACK_IMPORTED_MODULE_1__["Project"]();
                _this.isNew = true;
                //this.startDate = (new Date()).toISOString().substr(0, 10);
            }
        });
    };
    ViewProjectComponent.prototype.saveProject = function () {
        var _this = this;
        if (this.isNew) {
            this.project.startDate = new Date(this.startDate);
            this.project.endDate = new Date(this.endDate);
            this.projectService.addProject(this.project).subscribe(function (data) {
                alert("Project " + data.project + " is added successfully");
                _this.router.navigate(["/addProject"]);
            });
            //to clear form fields
            this.project.project = null;
            this.project.priority = null;
            this.userEmployeeId = null;
            this.startDate = null;
            this.endDate = null;
            this.checkedorNot = false;
        }
        else {
            this.updateProject();
        }
        this.projectService.getProjects().subscribe(function (empData) {
            _this.projects = empData;
        });
        window.location.href = "/addProject";
    };
    ViewProjectComponent.prototype.updateProject = function () {
        var _this = this;
        if (this.userId == null) {
            this.project.startDate = new Date(this.startDate);
            this.project.endDate = new Date(this.endDate);
            //alert(JSON.stringify(this.project));					
            this.projectService.updateProject(this.project).subscribe(function (data) {
                alert("Project " + data.project + " is updated successfully");
                _this.router.navigate(["/addProject"]);
            });
        }
        else {
            this.userService.getUsersById(this.userId).subscribe(function (data) {
                _this.user = data;
                _this.project.userId = _this.user;
                _this.project.startDate = new Date(_this.startDate);
                _this.project.endDate = new Date(_this.endDate);
                _this.projectService.updateProject(_this.project).subscribe(function (data) {
                    alert("Project " + data.project + " is updated successfully");
                    _this.router.navigate(["/addProject"]);
                });
            });
        }
    };
    ViewProjectComponent.prototype.dates = function (event) {
        if (event.target.checked) {
            this.checkedorNot = true;
            this.startDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
            this.endDate = (this.datePipe.transform(new Date().setDate(new Date().getDate() + 1), 'yyyy-MM-dd'));
        }
        else {
            this.checkedorNot = false;
            this.startDate = null;
            this.endDate = null;
        }
    };
    ViewProjectComponent.prototype.sortProjectStartDate = function () {
        if (this.startDateReverseSort) {
            this.startDateReverseSort = false;
            return this.projects.sort(function (a, b) { return a.startDate > b.startDate ? -1 : 1; });
        }
        else {
            this.startDateReverseSort = true;
            return this.projects.sort(function (a, b) { return a.startDate < b.startDate ? -1 : 1; });
        }
    };
    ViewProjectComponent.prototype.sortProjectEndDate = function () {
        if (this.endDateReverseSort) {
            this.endDateReverseSort = false;
            return this.projects.sort(function (a, b) { return a.endDate > b.endDate ? -1 : 1; });
        }
        else {
            this.endDateReverseSort = true;
            return this.projects.sort(function (a, b) { return a.endDate < b.endDate ? -1 : 1; });
        }
    };
    ViewProjectComponent.prototype.sortProjectPriority = function () {
        if (this.priorityReverseSort) {
            this.priorityReverseSort = false;
            return this.projects.sort(function (a, b) { return a.priority > b.priority ? -1 : 1; });
        }
        else {
            this.priorityReverseSort = true;
            return this.projects.sort(function (a, b) { return a.priority < b.priority ? -1 : 1; });
        }
    };
    ViewProjectComponent.prototype.sortProjectCompletedTask = function () {
        if (this.completedTaskReverseSort) {
            this.completedTaskReverseSort = false;
            return this.projects.sort(function (a, b) { return a.noOfCompletedTask > b.noOfCompletedTask ? -1 : 1; });
        }
        else {
            this.completedTaskReverseSort = true;
            return this.projects.sort(function (a, b) { return a.noOfCompletedTask < b.noOfCompletedTask ? -1 : 1; });
        }
    };
    ViewProjectComponent.prototype.addManagerModalSearchButtonLogic = function () {
        var _this = this;
        this.userService.getUsers().subscribe(function (empData) {
            _this.filteredManagerModalTasks = empData;
            _this.storeOrignalFilterManagerModalTasks = empData;
        });
        this.filterTaskId = null;
    };
    ViewProjectComponent.prototype.projectModalSelectButtonLogic = function (employeeId, userId) {
        this.userEmployeeId = employeeId;
        this.userId = userId;
    };
    ViewProjectComponent.prototype.insideManagerModalSearchButtonLogic = function () {
        var _this = this;
        var finalResult = this.filteredManagerModalTasks.filter(function (t) {
            if (t.employeeId == _this.filterTaskId) {
                return true;
            }
        });
        this.filteredManagerModalTasks = finalResult;
        //console.log(finalResult);
    };
    ViewProjectComponent.prototype.resetInsideManagerModalSearchButtonLogic = function () {
        this.filterTaskId = null;
        this.filteredManagerModalTasks = this.storeOrignalFilterManagerModalTasks;
    };
    ViewProjectComponent.prototype.endDateValidation = function () {
        if (!(this.endDate > this.startDate)) {
            this.endDate = null;
            alert("End Date should be greater than Start Date");
        }
    };
    ViewProjectComponent.prototype.filterBasedOnProjects = function () {
        var _this = this;
        var finalResult = this.projects.filter(function (singleProject) {
            if (singleProject.projectId == _this.filterProjectId) {
                return true;
            }
        });
        this.filteredProjectsList = finalResult;
    };
    ViewProjectComponent.prototype.resetfilterBasedOnProjects = function () {
        this.filteredProjectsList = this.storeOrignalFilterProjectsList;
    };
    ViewProjectComponent.prototype.addOnlyProjectModalSearchButtonLogic = function () {
        var _this = this;
        this.projectService.getProjects().subscribe(function (empData) {
            _this.filteredOnlyProjectModalTasks = empData;
            _this.storeOrignalFilterOnlyProjectModalTasks = empData;
        });
        this.filterproject = null;
    };
    ViewProjectComponent.prototype.onlyProjectModalSelectButtonLogic = function (employeeId, userId) {
        this.projectString = employeeId;
        this.projectId = userId;
        this.filterProjectId = this.projectId;
        //logic for Project view alone
        this.filterBasedOnProjects();
    };
    ViewProjectComponent.prototype.insideOnlyProjectModalSearchButtonLogic = function () {
        var _this = this;
        var finalResult = this.filteredOnlyProjectModalTasks.filter(function (t) {
            if (t.project == _this.filterproject) {
                return true;
            }
        });
        this.filteredOnlyProjectModalTasks = finalResult;
        //console.log(finalResult);
    };
    ViewProjectComponent.prototype.resetInsideOnlyProjectModalSearchButtonLogic = function () {
        this.filterproject = null;
        this.filteredOnlyProjectModalTasks = this.storeOrignalFilterOnlyProjectModalTasks;
    };
    ViewProjectComponent.prototype.endProject = function (projectId) {
        var _this = this;
        this.taskService.getTasks().subscribe(function (empData) {
            _this.tasks = empData;
            var arrayOfTaskId = [];
            _this.tasks.filter(function (t) {
                if (t.projectId != null && t.projectId.projectId == projectId) {
                    t.endDate = new Date();
                    arrayOfTaskId.push(t.taskId);
                    _this.taskService.updateTask(t).subscribe(function (data) {
                    });
                }
            });
            if (arrayOfTaskId.length > 0)
                alert("Mapped TaskId " + arrayOfTaskId + " ended successfully");
            else {
                alert("No Task mapped to this Project");
            }
        });
        window.location.href = "/addProject";
    };
    ViewProjectComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-view-project',
            template: __webpack_require__(/*! ./view-project.component.html */ "./src/app/view-project/view-project.component.html"),
            styles: [__webpack_require__(/*! ./view-project.component.css */ "./src/app/view-project/view-project.component.css")]
        }),
        __metadata("design:paramtypes", [src_app_services_project_service__WEBPACK_IMPORTED_MODULE_3__["ProjectService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"], src_app_services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"],
            src_app_services_task_service__WEBPACK_IMPORTED_MODULE_6__["TaskService"]])
    ], ViewProjectComponent);
    return ViewProjectComponent;
}());



/***/ }),

/***/ "./src/app/view-task/view-task.component.css":
/*!***************************************************!*\
  !*** ./src/app/view-task/view-task.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/view-task/view-task.component.html":
/*!****************************************************!*\
  !*** ./src/app/view-task/view-task.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid\">\n\n  <div class=\"row\">\n    <section>\n\n      <form class=\"form-inline\" #filterProjectForm=\"ngForm\">\n\n        <div class=\"form-group col-sm-12\">\n          <label>Project:</label>\n          <input disabled class=\"form-control\" type=\"text\" name=\"project\" [(ngModel)]=\"projectString\" />\n          <button type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#projectOnlyModal\" (click)=\"addOnlyProjectModalSearchButtonLogic() \">Search</button>\n          <button class=\"btn\" type=\"reset\" (click)=\"resetfilterBasedOnProjects()\">Reset</button>\n        </div>\n\n      </form>\n\n      <div class=\"form-group col-sm-3 \">\n        <br/>\n        <label> Sort By:</label>\n      </div>\n      <div class=\"btn-group col-sm-8\">\n        <br/>\n        <button type=\"button\" class=\"btn\" id=\"btnfname1\" (click)=sortProjectStartDate()>Start Date</button>\n        <button type=\"button\" class=\"btn\" id=\"btnlname\" (click)=sortProjectEndDate()>End Date</button>\n        <button type=\"button\" class=\"btn\" id=\"btneid\" (click)=sortProjectPriority()>Priority</button>\n        <button type=\"button\" class=\"btn\" id=\"btneid\" (click)=sortProjectCompletedTask()>Completed Tasks</button>\n      </div>\n      <div class=\"form-group col-sm-12 \">\n        Note: To complete a Task click on EndTask button and End date would be updated accordingly.\n      </div>\n\n\n      <div class=\"form-group col-sm-12\">\n        <div style=\"border-top: 1px solid\"></div>\n      </div>\n      <table class=\"table\">\n        <thead>\n          <tr>\n            <th>TaskId</th>\n            <th>Task</th>\n            <th>ParentTaskId</th>\n            <th>Priority</th>\n            <th>Start</th>\n            <th>End</th>\n          </tr>\n        </thead>\n        <tbody>\n          <tr *ngFor=\"let task of filteredTaskList\">\n            <td>{{task.taskId}}</td>\n            <td>{{task.task}}</td>\n            <td>\n              <div *ngIf='task.parentId'>\n                <td>{{task.parentId?.taskId}}</td>\n              </div>\n              <div *ngIf='task.parentId==null'>\n                <td>This Task Has No Parent</td>\n              </div>\n            </td>\n            <td>{{task.priority}}</td>\n            <td>{{task.startDate}}</td>\n            <td>{{task.endDate}}</td>\n            <td>\n              <button type=\"button\" class=\"btn\" id=\"btnAdd1\" [disabled]=\"task.endDate!=null\" [routerLink]=\"['/edit',task.taskId]\">Edit Task</button>\n            </td>\n            <td>\n              <button type=\"button\" class=\"btn\" id=\"btnAdd2\" [disabled]=\"task.endDate!=null\" (click)=\"endTask(task.taskId)\">End Task</button>\n            </td>\n\n          </tr>\n        </tbody>\n      </table>\n\n\n      <div id=\"projectOnlyModal\" class=\"modal fade\" role=\"dialog\">\n        <div class=\"modal-dialog\">\n\n          <!-- Modal content-->\n          <div class=\"modal-content\">\n            <div class=\"modal-header\">\n              <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n              <h4 class=\"modal-title\">Add Project</h4>\n            </div>\n            <div class=\"modal-body\">       \n\n              <form class=\"form-horizontal\" #projectForm=\"ngForm\">\n                <div class=\"form-group col-sm-12\">*Required Fields</div>\n                <div class=\"form-group col-sm-7\">\n                  <label>*Project:</label>\n                  <input placeholder=\"Enter Project\" class=\"form-control\" type=\"text\" name=\"Project\" [(ngModel)]=\"filterproject\" required/>\n                </div>\n\n                <div class=\"btn-group col-sm-2\">\n                  <button type=\"submit\" class=\"btn\" (click)=\"insideOnlyProjectModalSearchButtonLogic()\" [disabled]=\"!projectForm.form.valid\">Search</button>\n                </div>\n                <div class=\"btn-group col-sm-1\">\n                  <button type=\"reset\" class=\"btn\" (click)=\"resetInsideOnlyProjectModalSearchButtonLogic()\">Reset</button>\n                </div>\n\n              </form>\n\n\n              <table class=\"table\">\n                <thead>\n                  <tr>\n                    <th>ProjectId</th>\n                    <th>Project</th>\n                  </tr>\n                </thead>\n                <tbody>\n                  <tr *ngFor=\"let project of filteredOnlyProjectModalTasks\">\n                    <td>{{project.projectId}}</td>\n                    <td>{{project.project}}</td>\n                    <td>\n                      <button type=\"button\" class=\"btn\" id=\"btnAdd1\" data-dismiss=\"modal\" (click)=\"onlyProjectModalSelectButtonLogic(project.project,project.projectId)\">Select Task</button>\n                    </td>\n                  </tr>\n                </tbody>\n              </table>\n\n            </div>\n            <div class=\"modal-footer\">\n              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\n            </div>\n          </div>\n        </div>\n      </div>\n\n    </section>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/view-task/view-task.component.ts":
/*!**************************************************!*\
  !*** ./src/app/view-task/view-task.component.ts ***!
  \**************************************************/
/*! exports provided: ViewTaskComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewTaskComponent", function() { return ViewTaskComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_models_task__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/task */ "./src/app/models/task.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_task_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/task.service */ "./src/app/services/task.service.ts");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ViewTaskComponent = /** @class */ (function () {
    function ViewTaskComponent(taskService, datePipe, router, projectService) {
        this.taskService = taskService;
        this.datePipe = datePipe;
        this.router = router;
        this.projectService = projectService;
        this.dummy = "hii";
        this.filterTaskModel = new src_app_models_task__WEBPACK_IMPORTED_MODULE_1__["Task"]();
        this.finalFilterTaskModel = new src_app_models_task__WEBPACK_IMPORTED_MODULE_1__["Task"]();
        this.startDateReverseSort = false;
        this.priorityReverseSort = false;
        this.endDateReverseSort = false;
        this.completedTaskReverseSort = false;
    }
    ViewTaskComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.taskService.getTasks().subscribe(function (empData) {
            _this.tasks = empData;
            _this.storeOrignalFilterProjectsList = empData;
            _this.filteredTaskList = empData;
        });
    };
    ViewTaskComponent.prototype.endTask = function (taskId) {
        var _this = this;
        var arrayOfTaskId = [];
        arrayOfTaskId.push(taskId);
        var filteredChildTask = this.tasks.filter(function (t) {
            if (t.parentId != null && t.parentId.taskId == taskId) {
                arrayOfTaskId.push(t.taskId);
                return true;
            }
        });
        for (var i = 0; i < arrayOfTaskId.length; i++) {
            this.taskService.getTasksById(arrayOfTaskId[i]).subscribe(function (empData) {
                empData.endDate = new Date(_this.datePipe.transform(new Date(), 'yyyy-MM-dd'));
                _this.taskService.updateTask(empData).subscribe(function (data) {
                });
            });
        }
        alert("TaskId " + arrayOfTaskId + " ended successfully");
        window.location.href = "/";
    };
    ViewTaskComponent.prototype.buttonClick = function () {
        //the parentid from screen is set to null or valid numbers were ever required
        var dummyTask = new src_app_models_task__WEBPACK_IMPORTED_MODULE_1__["Task"]();
        var stringParentId = this.parentId.toString();
        if ("This Task Has No Parent" == stringParentId) {
            dummyTask = null;
        }
        else {
            dummyTask.taskId = this.parentId;
        }
        this.filterTaskModel.parentId = dummyTask;
        this.finalFilterTaskModel = this.filterTaskModel;
        var formValues = this.filterTaskModel;
        //retaining form value to populate in screen
        this.filterTaskModel = new src_app_models_task__WEBPACK_IMPORTED_MODULE_1__["Task"]();
        this.filterTaskModel.task = formValues.task;
        this.filterTaskModel.priority = formValues.priority;
        this.filterTaskModel.startDate = formValues.startDate;
        this.filterTaskModel.endDate = formValues.endDate;
    };
    ViewTaskComponent.prototype.restClick = function () {
        this.filterTaskModel.task = undefined;
        this.parentId = null;
        this.filterTaskModel.priority = undefined;
        this.filterTaskModel.startDate = undefined;
        this.filterTaskModel.endDate = undefined;
        this.finalFilterTaskModel = this.filterTaskModel;
        this.filterTaskModel = new src_app_models_task__WEBPACK_IMPORTED_MODULE_1__["Task"]();
    };
    ViewTaskComponent.prototype.filterBasedOnProjects = function () {
        var _this = this;
        var isAtLeastOneTaskPresent = false;
        var finalResult = this.tasks.filter(function (singleTask) {
            if (singleTask.projectId != null && singleTask.projectId.projectId == _this.filterProjectId) {
                isAtLeastOneTaskPresent = true;
                return true;
            }
        });
        if (!isAtLeastOneTaskPresent)
            alert("No Task mapped to this Project");
        this.filteredTaskList = finalResult;
    };
    ViewTaskComponent.prototype.resetfilterBasedOnProjects = function () {
        this.filteredTaskList = this.storeOrignalFilterProjectsList;
    };
    ViewTaskComponent.prototype.addOnlyProjectModalSearchButtonLogic = function () {
        var _this = this;
        this.projectService.getProjects().subscribe(function (empData) {
            _this.filteredOnlyProjectModalTasks = empData;
            _this.storeOrignalFilterOnlyProjectModalTasks = empData;
        });
        this.filterproject = null;
    };
    ViewTaskComponent.prototype.onlyProjectModalSelectButtonLogic = function (employeeId, userId) {
        this.projectString = employeeId;
        this.projectId = userId;
        //logic for Task view alone
        this.filterProjectId = this.projectId;
        //logic for Task view alone
        this.filterBasedOnProjects();
    };
    ViewTaskComponent.prototype.insideOnlyProjectModalSearchButtonLogic = function () {
        var _this = this;
        var finalResult = this.filteredOnlyProjectModalTasks.filter(function (t) {
            if (t.project == _this.filterproject) {
                return true;
            }
        });
        this.filteredOnlyProjectModalTasks = finalResult;
        //console.log(finalResult);
    };
    ViewTaskComponent.prototype.resetInsideOnlyProjectModalSearchButtonLogic = function () {
        this.filterproject = null;
        this.filteredOnlyProjectModalTasks = this.storeOrignalFilterOnlyProjectModalTasks;
    };
    ViewTaskComponent.prototype.sortProjectStartDate = function () {
        if (this.startDateReverseSort) {
            this.startDateReverseSort = false;
            return this.tasks.sort(function (a, b) { return a.startDate > b.startDate ? -1 : 1; });
        }
        else {
            this.startDateReverseSort = true;
            return this.tasks.sort(function (a, b) { return a.startDate < b.startDate ? -1 : 1; });
        }
    };
    ViewTaskComponent.prototype.sortProjectEndDate = function () {
        if (this.endDateReverseSort) {
            this.endDateReverseSort = false;
            return this.tasks.sort(function (a, b) { return a.endDate > b.endDate ? -1 : 1; });
        }
        else {
            this.endDateReverseSort = true;
            return this.tasks.sort(function (a, b) { return a.endDate < b.endDate ? -1 : 1; });
        }
    };
    ViewTaskComponent.prototype.sortProjectPriority = function () {
        if (this.priorityReverseSort) {
            this.priorityReverseSort = false;
            return this.tasks.sort(function (a, b) { return a.priority > b.priority ? -1 : 1; });
        }
        else {
            this.priorityReverseSort = true;
            return this.tasks.sort(function (a, b) { return a.priority < b.priority ? -1 : 1; });
        }
    };
    ViewTaskComponent.prototype.sortProjectCompletedTask = function () {
        if (this.completedTaskReverseSort) {
            this.completedTaskReverseSort = false;
            return this.tasks.sort(function (a, b) { return a.endDate == null ? -1 : 1; });
        }
        else {
            this.completedTaskReverseSort = true;
            return this.tasks.sort(function (a, b) { return a.endDate != null ? -1 : 1; });
        }
    };
    ViewTaskComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-view-task',
            template: __webpack_require__(/*! ./view-task.component.html */ "./src/app/view-task/view-task.component.html"),
            styles: [__webpack_require__(/*! ./view-task.component.css */ "./src/app/view-task/view-task.component.css")]
        }),
        __metadata("design:paramtypes", [src_app_services_task_service__WEBPACK_IMPORTED_MODULE_4__["TaskService"],
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], src_app_services_project_service__WEBPACK_IMPORTED_MODULE_5__["ProjectService"]])
    ], ViewTaskComponent);
    return ViewTaskComponent;
}());



/***/ }),

/***/ "./src/app/view-user/view-user.component.css":
/*!***************************************************!*\
  !*** ./src/app/view-user/view-user.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/view-user/view-user.component.html":
/*!****************************************************!*\
  !*** ./src/app/view-user/view-user.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container-fluid\">\n\n  <div class=\"row\">\n    <section>\n\n      <form class=\"form-horizontal\" #heroForm=\"ngForm\">\n        <div class=\"form-group col-sm-12\">*Required Fields</div>\n        <div class=\"form-group col-sm-7\">\n          <label>*First Name:</label>\n          <input placeholder=\"Enter FirstName\" class=\"form-control\" type=\"text\" name=\"fname\" [(ngModel)]=\"user.firstName\" required/>\n        </div>\n\n        <div class=\"form-group col-sm-7\">\n          <label>*Last Name:</label>\n          <input placeholder=\"Enter LastName\" class=\"form-control\" type=\"text\" name=\"lname\" [(ngModel)]=\"user.lastName\" required />\n        </div>\n\n        <div class=\"form-group col-sm-7\">\n          <label>*Employee Id:</label>\n          <input placeholder=\"Enter EmployeeId\" class=\"form-control\" type=\"text\" name=\"eid\" [(ngModel)]=\"user.employeeId\" required/>\n        </div>\n\n\n        <div class=\"btn-group col-sm-12\">\n          <button *ngIf=\"isNew\" class=\"btn\" type=\"submit\" (click)=\"saveUser()\" [disabled]=\"!heroForm.form.valid\">Add User</button>\n          <button *ngIf=\"!isNew\" class=\"btn\" type=\"submit\" (click)=\"saveUser()\" [disabled]=\"!heroForm.form.valid\">Update</button>\n          <button class=\"btn\" type=\"reset\">Reset</button>\n\n        </div>\n\n      </form>\n\n      <div class=\"form-group col-sm-12\">\n        <br/>\n          <div style=\"border-top: 1px solid\"></div>\n      </div>\n\n\n      <form class=\"form-inline\" #filterProjectForm=\"ngForm\">\n        <div class=\"form-group col-sm-7\">\n          <label>User:</label>\n          <input disabled class=\"form-control\" type=\"text\" name=\"userId\" [(ngModel)]=\"userEmployeeId\" />\n          <button type=\"button\" class=\"btn\" data-toggle=\"modal\" data-target=\"#projectModal\" (click)=\"addManagerModalSearchButtonLogic() \">Search</button>\n          <button class=\"btn\" type=\"reset\" (click)=\"resetfilterBasedOnProjects()\">Reset</button>\n        </div>\n      </form>\n\n      <div class=\"form-group col-sm-6 \">\n        <br/>\n        <label> Sort By:</label>\n      </div>\n\n      <div class=\"btn-group col-sm-4\">\n          <br/>\n        <button type=\"button\" class=\"btn\" id=\"btnfname1\" (click)=sortUserFirstName()>FirstName</button>\n        <button type=\"button\" class=\"btn\" id=\"btnlname\" (click)=sortUserLastName()>LastName</button>\n        <button type=\"button\" class=\"btn\" id=\"btneid\" (click)=sortUserEmployeeId()>EmployeeId</button>\n      </div>\n      <table class=\"table\">\n        <thead>\n          <tr>\n            <th>UserId</th>\n            <th>FirstName</th>\n            <th>LastName</th>\n            <th>EmployeeId</th>\n\n          </tr>\n        </thead>\n        <tbody>\n          <tr *ngFor=\"let user of filteredUserList\">\n            <td>{{user.userId}}</td>\n            <td>{{user.firstName}}</td>\n            <td>{{user.lastName}}</td>\n            <td>{{user.employeeId}}</td>\n            <td>\n              <button type=\"button\" class=\"btn\" id=\"btnAdd1\" [routerLink]=\"['/editUser',user.userId]\">Edit</button>\n            </td>\n            <td>\n              <button type=\"button\" class=\"btn\" id=\"btnAdd2\" (click)=\"deleteUser(user.userId)\">Delete</button>\n            </td>\n\n          </tr>\n        </tbody>\n      </table>\n\n\n      <div id=\"projectModal\" class=\"modal fade\" role=\"dialog\">\n        <div class=\"modal-dialog\">\n\n          <!-- Modal content-->\n          <div class=\"modal-content\">\n            <div class=\"modal-header\">\n              <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\n              <h4 class=\"modal-title\">Add User</h4>\n            </div>\n            <div class=\"modal-body\">\n              \n              <form class=\"form-inline\" #projectModalForm=\"ngForm\">\n                <div class=\"form-group col-sm-9\">*Required Fields</div>\n                <div class=\"form-group col-sm-12\">\n                  <label>*EmployeeId:</label>\n                  <div>\n                    <input class=\"form-control\" type=\"text\" placeholder=\"Enter EmployeeId\" name=\"filterTaskId\" [(ngModel)]=\"filterTaskId\" required/>\n                  </div>\n                </div>\n                <div class=\"btn-group col-sm-2\">\n                  <button type=\"submit\" class=\"btn\" (click)=\"insideManagerModalSearchButtonLogic()\" [disabled]=\"!projectModalForm.form.valid\">Search</button>\n                </div>\n                <div class=\"btn-group col-sm-1\">\n                  <button type=\"reset\" class=\"btn\" (click)=\"resetInsideManagerModalSearchButtonLogic()\">Reset</button>\n                </div>\n              </form>\n\n\n\n              <table class=\"table\">\n                <thead>\n                  <tr>\n                    <th>UserId</th>\n                    <th>FirstName</th>\n                    <th>LastName</th>\n                    <th>EmployeeId</th>\n                  </tr>\n                </thead>\n                <tbody>\n                  <tr *ngFor=\"let user of filteredManagerModalTasks\">\n                    <td>{{user.userId}}</td>\n                    <td>{{user.firstName}}</td>\n                    <td>{{user.lastName}}</td>\n                    <td>{{user.employeeId}}</td>\n                    <td>\n                      <button type=\"button\" class=\"btn\" id=\"btnAdd1\" data-dismiss=\"modal\" (click)=\"projectModalSelectButtonLogic(user.employeeId,user.userId)\">Select Task</button>\n                    </td>\n                  </tr>\n                </tbody>\n              </table>\n\n            </div>\n            <div class=\"modal-footer\">\n              <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\n            </div>\n          </div>\n        </div>\n      </div>\n\n    </section>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/view-user/view-user.component.ts":
/*!**************************************************!*\
  !*** ./src/app/view-user/view-user.component.ts ***!
  \**************************************************/
/*! exports provided: ViewUserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewUserComponent", function() { return ViewUserComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_models_user__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/models/user */ "./src/app/models/user.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var src_app_services_project_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/project.service */ "./src/app/services/project.service.ts");
/* harmony import */ var src_app_services_task_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/task.service */ "./src/app/services/task.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ViewUserComponent = /** @class */ (function () {
    function ViewUserComponent(userService, router, route, projectService, taskService) {
        this.userService = userService;
        this.router = router;
        this.route = route;
        this.projectService = projectService;
        this.taskService = taskService;
        this.firstnameReverseSort = false;
        this.lastnameReverseSort = false;
        this.employeeReverseSort = false;
    }
    ViewUserComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.getUsers().subscribe(function (empData) {
            _this.users = empData;
            _this.filteredUserList = empData;
            _this.storeOrignalFilterProjectsList = empData;
        });
        this.route.params.subscribe(function (params) {
            if (params['id'] != null) {
                _this.userService.getUsersById(params['id']).subscribe(function (data) {
                    _this.user = data;
                });
                _this.isNew = false;
            }
            else {
                _this.user = new src_app_models_user__WEBPACK_IMPORTED_MODULE_1__["User"]();
                _this.isNew = true;
                //this.startDate = (new Date()).toISOString().substr(0, 10);
            }
        });
    };
    ViewUserComponent.prototype.saveUser = function () {
        var _this = this;
        if (this.isNew) {
            this.userService.addUser(this.user).subscribe(function (data) {
                alert(data.employeeId + " is added successfully");
                _this.router.navigate(["/addUser"]);
            });
        }
        else {
            this.userService.updateUser(this.user).subscribe(function (data) {
                alert(data.employeeId + "is updated successfully");
                _this.router.navigate(["/addUser"]);
            });
        }
        this.userService.getUsers().subscribe(function (empData) {
            _this.users = empData;
        });
        //to clear form fields
        this.user.firstName = null;
        this.user.lastName = null;
        this.user.employeeId = null;
        window.location.href = "/addUser";
    };
    ViewUserComponent.prototype.deleteUser = function (userId) {
        var _this = this;
        var arrayOfProjectId = [];
        var arrayOfTaskId = [];
        //project fetch all
        this.projectService.getProjects().subscribe(function (empData) {
            var project = empData;
            project.filter(function (p) {
                if (p.userId != null && userId == p.userId.userId) {
                    //alert(p.userId.userId);
                    p.userId = null;
                    arrayOfProjectId.push(p.projectId);
                    //project update one entry
                    _this.projectService.updateProject(p).subscribe(function (data) {
                    });
                }
            });
            //Task fetch all
            _this.taskService.getTasks().subscribe(function (taskData) {
                var task = taskData;
                task.filter(function (t) {
                    if (t.userId != null && t.userId.userId == userId) {
                        t.userId = null;
                        arrayOfTaskId.push(t.taskId);
                        //Task update one entry
                        _this.taskService.updateTask(t).subscribe(function (data) {
                            //delete user entry
                            _this.userService.deleteUsersById(userId).subscribe(function (data) {
                                var msg = "EmployeeId " + data.employeeId + " is deleted successfully";
                                var msg1 = ". EmployeedId is removed in mapped";
                                if (arrayOfProjectId.length > 0) {
                                    msg1 = msg1 + " Projects " + arrayOfProjectId;
                                }
                                if (arrayOfTaskId.length > 0) {
                                    msg1 = msg1 + ",Tasks " + arrayOfTaskId;
                                }
                                if (arrayOfProjectId.length > 0 || arrayOfTaskId.length > 0) {
                                    msg = msg + msg1;
                                }
                                alert(msg);
                                window.location.href = "/addUser";
                            });
                        });
                    }
                });
                if (arrayOfTaskId.length <= 0) {
                    //alert("delete user now alone");
                    _this.userService.deleteUsersById(userId).subscribe(function (data) {
                        var msg = "EmployeeId " + data.employeeId + " is deleted successfully";
                        var msg1 = ". EmployeedId is removed in mapped";
                        if (arrayOfProjectId.length > 0) {
                            msg1 = msg1 + " Projects " + arrayOfProjectId;
                        }
                        if (arrayOfTaskId.length > 0) {
                            msg1 = msg1 + ",Tasks " + arrayOfTaskId;
                        }
                        if (arrayOfProjectId.length > 0 || arrayOfTaskId.length > 0) {
                            msg = msg + msg1;
                        }
                        alert(msg);
                        window.location.href = "/addUser";
                    });
                }
            });
        });
    };
    ViewUserComponent.prototype.sortUserFirstName = function () {
        if (this.firstnameReverseSort) {
            this.firstnameReverseSort = false;
            return this.users.sort(function (a, b) { return a.firstName > b.firstName ? -1 : 1; });
        }
        else {
            this.firstnameReverseSort = true;
            return this.users.sort(function (a, b) { return a.firstName < b.firstName ? -1 : 1; });
        }
    };
    ViewUserComponent.prototype.sortUserLastName = function () {
        if (this.lastnameReverseSort) {
            this.lastnameReverseSort = false;
            return this.users.sort(function (a, b) { return a.lastName > b.lastName ? -1 : 1; });
        }
        else {
            this.lastnameReverseSort = true;
            return this.users.sort(function (a, b) { return a.lastName < b.lastName ? -1 : 1; });
        }
    };
    ViewUserComponent.prototype.sortUserEmployeeId = function () {
        if (this.employeeReverseSort) {
            this.employeeReverseSort = false;
            return this.users.sort(function (a, b) { return a.employeeId > b.employeeId ? -1 : 1; });
        }
        else {
            this.employeeReverseSort = true;
            return this.users.sort(function (a, b) { return a.employeeId < b.employeeId ? -1 : 1; });
        }
    };
    ViewUserComponent.prototype.addManagerModalSearchButtonLogic = function () {
        var _this = this;
        this.userService.getUsers().subscribe(function (empData) {
            _this.filteredManagerModalTasks = empData;
            _this.storeOrignalFilterManagerModalTasks = empData;
        });
        this.filterTaskId = null;
    };
    ViewUserComponent.prototype.projectModalSelectButtonLogic = function (employeeId, userId) {
        this.userEmployeeId = employeeId;
        this.userId = userId;
        ///
        this.filterBasedOnProjects();
    };
    ViewUserComponent.prototype.insideManagerModalSearchButtonLogic = function () {
        //alert(this.filterTaskId);
        var _this = this;
        var finalResult = this.filteredManagerModalTasks.filter(function (t) {
            if (t.employeeId == _this.filterTaskId) {
                return true;
            }
        });
        this.filteredManagerModalTasks = finalResult;
        //console.log(finalResult);
    };
    ViewUserComponent.prototype.resetInsideManagerModalSearchButtonLogic = function () {
        this.filterTaskId = null;
        this.filteredManagerModalTasks = this.storeOrignalFilterManagerModalTasks;
    };
    ViewUserComponent.prototype.filterBasedOnProjects = function () {
        var _this = this;
        var finalResult = this.users.filter(function (singleUser) {
            if (singleUser.employeeId == _this.userEmployeeId) {
                return true;
            }
        });
        this.filteredUserList = finalResult;
    };
    ViewUserComponent.prototype.resetfilterBasedOnProjects = function () {
        this.filteredUserList = this.storeOrignalFilterProjectsList;
    };
    ViewUserComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-view-user',
            template: __webpack_require__(/*! ./view-user.component.html */ "./src/app/view-user/view-user.component.html"),
            styles: [__webpack_require__(/*! ./view-user.component.css */ "./src/app/view-user/view-user.component.css")]
        }),
        __metadata("design:paramtypes", [src_app_services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            src_app_services_project_service__WEBPACK_IMPORTED_MODULE_4__["ProjectService"], src_app_services_task_service__WEBPACK_IMPORTED_MODULE_5__["TaskService"]])
    ], ViewUserComponent);
    return ViewUserComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    baseEmpUrl: 'http://localhost:5555/task',
    baseUserUrl: 'http://localhost:5555/user',
    baseProjectUrl: 'http://localhost:5555/project'
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Bala\workspace\vsc\ProjectManagerCertification\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map